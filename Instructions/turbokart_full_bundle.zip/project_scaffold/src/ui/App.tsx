import React from 'react'

export function App() {
  return (
    <div className="hud">
      <div style={{ padding: 16, color: 'white', fontFamily: 'system-ui' }}>
        <strong>Project TurboKart</strong> — HUD placeholder
      </div>
    </div>
  )
}
