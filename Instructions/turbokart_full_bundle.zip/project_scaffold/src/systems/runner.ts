// Wire up system execution order here
export function runAllSystems(dt: number) {
  // TODO: Input → Drive/Drift → Items → AI → Lap/Checkpoint → VFX → HUDBridge
}
