# Project TurboKart — Starter Scaffold

Run `pnpm install` then `pnpm dev`.
