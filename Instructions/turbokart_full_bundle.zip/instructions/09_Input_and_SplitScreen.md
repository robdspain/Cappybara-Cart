# 09 — Input & Split-Screen
**Keyboard (P1):** W/S throttle/brake, A/D steer, Shift drift, Space item, Q look back, E horn  
**Gamepad:** RT throttle, LT brake, LS steer, A item, B drift, Y look back

## Local Multiplayer
- Up to 4 splits
- Auto render-scale per viewport (0.7–1.0)
- Per-quadrant HUD
