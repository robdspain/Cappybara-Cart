# 01 — Vision & Scope
**Elevator Pitch:** Fast, readable, Mario Kart–style racing in the browser. 3-race sets, items, drifts, upgrades, and smart AI.

## MVP Must-Haves
- Single player vs 7 AI
- Local multiplayer up to 4 (split-screen)
- 3 tracks, 4 characters, kart upgrades
- Item system with weighted rolls by position
- 60 FPS target on modern desktop browsers

## Nice-to-Haves (Defer)
- Online multiplayer
- Weather variants, ghost replays, photo mode
- Cosmetics shop (skins only)
