# 18 — Test Plans & Acceptance Criteria
## Driving
- Achieve and maintain top speed; drift charges correctly; mini-turbo applies on release

## Items
- All items function; lightning cooldown respected; shield blocks one hit

## AI
- Uses overtake lines; difficulty scales within bounds; no impossible catch-ups

## Tracks
- No lap skips; anti-cut works; item box counts match spec

## Performance
- 60 FPS on target hardware; no hitching on split-screen
