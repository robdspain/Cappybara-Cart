# 16 — Tuning JSONs (Live-Tweak)
**`/content/item_weights.json`**
- Weighted item tables per position band
**`/content/dda.json`**
- Bounds and aggression for AI scaling

**Rules**
- Never hard-code weights; always read from JSON
- Support reload at runtime (debug hotkey)
