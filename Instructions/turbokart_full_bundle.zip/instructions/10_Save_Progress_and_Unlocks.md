# 10 — Save/Progress & Unlocks
**Storage:** LocalStorage (cloud sync later)

## Schema (summary)
- coins, unlockedCharacters[], upgrades {engine 0–3, tires 0–3, turbo 0–3, armor 0–2}
- stats {races, wins, bestLaps per track}
- settings {a11y, input}

## Unlock Paths
- ≥24 points in a set → character A
- Two clean laps (no crashes) → character B
- 1st in all three races in a cup → character C

## Coins by Place
- [20,12,8,6,5,4,3,2]
